<?php
namespace Simcify;

use Pecee\SimpleRouter\SimpleRouter;

class Router extends SimpleRouter {}
