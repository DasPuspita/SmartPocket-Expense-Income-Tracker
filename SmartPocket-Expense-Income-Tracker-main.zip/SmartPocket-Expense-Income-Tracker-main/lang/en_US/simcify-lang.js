/*
 * Messages
 */

var OkayButton = "Okay"
var CancelButton = "Cancel"



var daysSunday = "Sunday"
var daysMonday = "Monday"
var daysTuesday = "Tuesday"
var daysWednesday = "Wednesday"
var daysThursday = "Thursday"
var daysFriday = "Friday"
var daysSaturday = "Saturday"

var daysShortSunday = "Sun"
var daysShortMonday = "Mon"
var daysShortTuesday = "Tues"
var daysShortWednesday = "Wed"
var daysShortThursday = "Thu"
var daysShortFriday = "Fri"
var daysShortSaturday = "Sat"

var daysMinSunday = "Su"
var daysMinMonday = "Mo"
var daysMinTuesday = "Tu"
var daysMinWednesday = "We"
var daysMinThursday = "Th"
var daysMinFriday = "Fr"
var daysMinSaturday = "Sa"



var monthsJanuary = "January"
var monthsFebruary = "February"
var monthsMarch = "March"
var monthsApril = "April"
var monthsMay = "May"
var monthsJune = "June"
var monthsJuly = "July"
var monthsAugust = "August"
var monthsSeptember = "September"
var monthsOctober = "October"
var monthsNovember = "November"
var monthsDecember = "December"

var monthsShortJanuary = "Jan"
var monthsShortFebruary = "Feb"
var monthsShortMarch = "Mar"
var monthsShortApril = "Apr"
var monthsShortMay = "May"
var monthsShortJune = "Jun"
var monthsShortJuly = "Jul"
var monthsShortAugust = "Aug"
var monthsShortSeptember = "Sep"
var monthsShortOctober = "Oct"
var monthsShortNovember = "Nov"
var monthsShortDecember = "Dec"

