# SmartPocket – Income & Expense Tracker

SmartPocket is a PHP and MySQL-based web application designed to help users manage income, expenses, budgets, and financial reports.

## Features
- User authentication
- Expense management (CRUD)
- Income tracking
- Budget planning
- Dashboard overview
- Admin & user roles

## Technologies Used
- PHP 7.4+
- MySQL (XAMPP)
- Simcify Framework
- Bootstrap
- jQuery

## Installation
1. Clone the repository
2. Move project to `htdocs`
3. Import database from `/database`
4. Rename `.env_example` to `.env`
5. Update database credentials
6. Run on browser via `localhost`

## Admin Credentials 
username: rabingadal123@gmail.com
password: passqw

## Author
Rabin Gadal
