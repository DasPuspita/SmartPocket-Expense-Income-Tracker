<?php
    return array(
        'name'  => 'simcify'
    );
    