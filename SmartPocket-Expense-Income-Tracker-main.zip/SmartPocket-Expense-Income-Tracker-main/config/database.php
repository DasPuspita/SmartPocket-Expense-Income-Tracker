<?php

return [
    'host'      => env('DB_HOST', 'localhost'),
    'database'  => env('DB_DATABASE', 'database'),
    'username'  => env('DB_USERNAME', 'username'),
    'password'  => env('DB_PASSWORD', 'password'),
];
