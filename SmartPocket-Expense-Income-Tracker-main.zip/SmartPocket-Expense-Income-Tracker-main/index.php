<?php

// ini_set('display_errors', 'Off');
// error_reporting(0);

// ini_set('display_errors', 1);
// error_reporting(E_ALL);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');


include_once 'vendor/autoload.php';

use Simcify\Application;

$app = new Application();
